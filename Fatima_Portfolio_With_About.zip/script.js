
function downloadResume(){
  const link=document.createElement('a');
  link.href='resume.html';
  link.download='Fatima_Omer_Resume.html';
  link.click();
}
